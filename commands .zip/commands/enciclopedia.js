const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
	data: new SlashCommandBuilder()
	.setName('enciclopedia')
	.setDescription('l\'enciclopedia della cgi')
	
	.addSubcommand(subcommand =>
		subcommand
			.setName('cgi')
			.setDescription('cosa è la cgi'))
	
	.addSubcommand(subcommand =>
		subcommand
			.setName('retopology')
			.setDescription('Cosa è il retopology'))
	
	.addSubcommand(subcommand =>
		subcommand
			.setName('viewport')
			.setDescription('Cosa è il viewport'))
	}