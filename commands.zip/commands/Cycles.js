const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('cycles')
		.setDescription('Cosa è Cycles'),
	async execute(interaction) {
		interaction.reply({
			content: 'Cycles è uno dei motori di rendering di blender, è meglio di eevee ehehehehe',
			emphemeral: true
		});
	}
}